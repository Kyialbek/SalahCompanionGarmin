using Toybox.Graphics;
using Toybox.System;
using Toybox.WatchUi;

class SalahView extends WatchUi.View {
    function initialize() {
        View.initialize();
    }

    function onUpdate(dc) {
        var width = dc.getWidth();
        var height = dc.getHeight();
        var next = SalahTimes.nextPrayer();
        var zikr = SalahStore.getZikr();
        var done = SalahStore.isPrayerDone(next["key"]);

        dc.setColor(Graphics.COLOR_BLACK, Graphics.COLOR_BLACK);
        dc.clear();

        dc.setColor(Graphics.COLOR_WHITE, Graphics.COLOR_TRANSPARENT);
        dc.drawText(width / 2, 16, Graphics.FONT_SMALL, "Salah", Graphics.TEXT_JUSTIFY_CENTER);

        dc.setColor(0x55D68A, Graphics.COLOR_TRANSPARENT);
        dc.drawText(width / 2, height * 0.22, Graphics.FONT_LARGE, next["name"], Graphics.TEXT_JUSTIFY_CENTER);

        dc.setColor(Graphics.COLOR_WHITE, Graphics.COLOR_TRANSPARENT);
        dc.drawText(width / 2, height * 0.42, Graphics.FONT_NUMBER_MEDIUM, next["time"], Graphics.TEXT_JUSTIFY_CENTER);
        dc.drawText(width / 2, height * 0.58, Graphics.FONT_MEDIUM, next["remaining"], Graphics.TEXT_JUSTIFY_CENTER);

        dc.setColor(done ? 0x55D68A : Graphics.COLOR_LT_GRAY, Graphics.COLOR_TRANSPARENT);
        dc.drawText(width / 2, height * 0.72, Graphics.FONT_SMALL, done ? "Marked prayed" : "Back = prayed", Graphics.TEXT_JUSTIFY_CENTER);

        dc.setColor(Graphics.COLOR_WHITE, Graphics.COLOR_TRANSPARENT);
        dc.drawText(width / 2, height * 0.84, Graphics.FONT_SMALL, "Select zikr: " + zikr, Graphics.TEXT_JUSTIFY_CENTER);
    }
}
